@echo off
node "%~dp0package\bin\openclaude" %*
